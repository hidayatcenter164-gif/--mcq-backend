# backend/app/middleware/validation.py
from fastapi import Request
from fastapi.responses import JSONResponse
import time

async def validation_middleware(request: Request, call_next):
    """Middleware for request validation"""
    
    # Skip for health check
    if request.url.path.endswith("/health"):
        return await call_next(request)
    
    # Check content type for POST requests
    if request.method == "POST":
        content_type = request.headers.get("content-type", "")
        if "application/json" not in content_type:
            return JSONResponse(
                status_code=415,
                content={"detail": "Unsupported Media Type. Use application/json"}
            )
    
    # Add processing time header
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    return response