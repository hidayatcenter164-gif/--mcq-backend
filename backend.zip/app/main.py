# backend/app/main.py

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from enum import Enum
import logging
import asyncio

# ✅ Import AI logic
from app.ai_client import ask_ai

# --------------------------------------------------
# App initialization
# --------------------------------------------------

app = FastAPI(
    title="Arabic Grammar MCQ Generator",
    version="1.0.0"
)

# --------------------------------------------------
# CORS (required for mobile + web)
# --------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],      # 🔓 Allow all (OK for development)
    allow_methods=["*"],
    allow_headers=["*"],
)

# --------------------------------------------------
# Logging setup
# --------------------------------------------------

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --------------------------------------------------
# Request Models
# --------------------------------------------------

class DifficultyLevel(str, Enum):
    easy = "easy"
    medium = "medium"
    hard = "hard"

class MCQRequest(BaseModel):
    arabic_text: str = Field(
        ...,
        min_length=50,
        description="Arabic grammar paragraph"
    )
    difficulty: DifficultyLevel
    num_questions: int = Field(
        ge=1,
        le=20,
        description="Number of MCQs to generate"
    )

# --------------------------------------------------
# API Endpoint
# --------------------------------------------------

@app.post("/generate-mcq")
async def generate_mcq(request: MCQRequest):
    """
    Generate Arabic grammar MCQs using AI (DeepSeek via OpenRouter)
    """

    try:
        # 🔹 Run blocking AI call safely in thread
        ai_response = await asyncio.to_thread(
            ask_ai,
            request.arabic_text,
            request.difficulty.value,
            request.num_questions
        )

        # 🔹 Validate AI response structure
        if not isinstance(ai_response, dict):
            raise HTTPException(
                status_code=500,
                detail="AI returned invalid response format"
            )

        if "questions" not in ai_response:
            raise HTTPException(
                status_code=500,
                detail="AI response missing 'questions'"
            )

        return ai_response

    except HTTPException:
        # Re-raise known HTTP errors
        raise

    except Exception as e:
        # 🔴 Log full error for backend debugging
        logger.exception("MCQ generation failed")

        # 🔴 Clean message for frontend
        raise HTTPException(
            status_code=500,
            detail="Failed to generate MCQs"
        )

# --------------------------------------------------
# Health Check (for testing)
# --------------------------------------------------

@app.get("/health")
def health_check():
    return {"status": "ok"}