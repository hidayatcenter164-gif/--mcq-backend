# backend/app/config.py

from pydantic_settings import BaseSettings
from pathlib import Path

# Get path of backend folder safely (works on mobile too)
BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    # This will load your OpenRouter API key
    ai_api_key: str

    class Config:
        # Explicit path to api.env
        env_file = BASE_DIR / "api.env"
        env_file_encoding = "utf-8"

# Create settings object
settings = Settings()