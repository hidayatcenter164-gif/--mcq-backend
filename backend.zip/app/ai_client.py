# backend/app/ai_client.py

import requests
import json
import re
from app.config import settings

# ✅ OpenRouter endpoint (NOT DeepSeek direct)
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

# --------------------------------------------------
# This function sends Arabic grammar text to AI
# and gets MCQ questions in JSON format
# --------------------------------------------------
def ask_ai(arabic_text: str, difficulty: str, num_questions: int):
    """
    arabic_text   : Arabic grammar paragraph
    difficulty    : easy | medium | hard
    num_questions : number of MCQs
    """

    # 🔹 Strong system prompt to FORCE JSON output
    prompt = f"""
أنت نظام ذكي متخصص في النحو والصرف العربي.

المطلوب:
- أنشئ {num_questions} أسئلة اختيار من متعدد
- مستوى الصعوبة: {difficulty}

النص:
{arabic_text}

الشروط الصارمة:
1. أعد النتيجة بصيغة JSON فقط
2. لا تكتب أي شرح خارج JSON
3. كل سؤال يحتوي على:
   - question
   - options (4 فقط)
   - correct_answer
   - explanation

صيغة JSON المطلوبة:
{{
  "questions": [
    {{
      "question": "",
      "options": ["", "", "", ""],
      "correct_answer": "",
      "explanation": ""
    }}
  ]
}}
"""

    # 🔹 Send request to OpenRouter
    response = requests.post(
        OPENROUTER_URL,
        headers={
            # 🔑 API key from api.env
            "Authorization": f"Bearer {settings.ai_api_key}",

            # ✅ REQUIRED by OpenRouter
            "HTTP-Referer": "http://localhost",
            "X-Title": "Arabic Grammar MCQ Generator",

            "Content-Type": "application/json"
        },
        json={
            # ✅ Correct OpenRouter model
            "model": "deepseek/deepseek-r1-0528:free",

            "messages": [
                {"role": "user", "content": prompt}
            ],

            # Low temperature = more accurate MCQs
            "temperature": 0.3
        },
        timeout=60
    )

    # ❌ If API fails → stop here
    response.raise_for_status()

    # 🔹 Get raw AI text
    ai_text = response.json()["choices"][0]["message"]["content"]

    # --------------------------------------------------
    # 🔐 SAFETY: Extract JSON even if AI adds extra text
    # --------------------------------------------------
    try:
        # Find first JSON block using regex
        json_match = re.search(r"\{.*\}", ai_text, re.DOTALL)

        if not json_match:
            raise ValueError("No JSON found in AI response")

        clean_json = json_match.group()
        return json.loads(clean_json)

    except Exception as e:
        # Helpful error for debugging
        raise ValueError(f"Invalid AI JSON response: {e}")