# backend/tests/test_api.py
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_generate_mcq_success():
    arabic_text = "ذهب الطالب إلى المدرسة. كان الطالب مجتهداً. أعطى المعلم الطالب علامات جيدة."
    
    response = client.post(
        "/generate-mcq",
        json={
            "arabic_text": arabic_text,
            "difficulty": "medium",
            "num_questions": 3
        }
    )
    
    assert response.status_code == 200
    data = response.json()
    assert "questions" in data
    assert len(data["questions"]) > 0
    
    # Validate each question structure
    for q in data["questions"]:
        assert "question" in q
        assert "options" in q and len(q["options"]) == 4
        assert "correct_answer" in q
        assert "explanation" in q
        assert q["correct_answer"] in q["options"]

def test_generate_mcq_invalid_text():
    response = client.post(
        "/generate-mcq",
        json={
            "arabic_text": "short",
            "difficulty": "medium",
            "num_questions": 3
        }
    )
    
    assert response.status_code == 422  # Validation error

def test_generate_mcq_non_arabic():
    response = client.post(
        "/generate-mcq",
        json={
            "arabic_text": "This is English text not Arabic",
            "difficulty": "medium",
            "num_questions": 3
        }
    )
    
    assert response.status_code == 400  # Arabic validation error

if __name__ == "__main__":
    pytest.main([__file__])